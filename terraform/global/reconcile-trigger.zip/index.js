// Invoked by SNS when the Azure health check recovers. Calls the AWS
// reconcile endpoint so AWS pushes any writes Azure missed while it was
// down. Reuses the shared replication secret for auth.
//
// A recovered health check means Azure can answer /health (a SELECT 1),
// but its Functions worker may not yet be warm enough to accept the
// /replicate/* writes. So the first reconcile can report failures. This
// handler retries on any reported failure, backing off between attempts,
// until the sync completes cleanly or the attempts are exhausted. This
// self-corrects regardless of how long Azure takes to become write-ready.
const https = require('https');

const MAX_ATTEMPTS = 4;
const BACKOFF_MS = 30000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function callReconcile() {
  const url = new URL(process.env.RECONCILE_URL);
  const body = JSON.stringify({ trigger: 'azure-recovery' });
  const options = {
    method: 'POST',
    hostname: url.hostname,
    path: url.pathname,
    headers: {
      'Content-Type': 'application/json',
      'x-replication-key': process.env.REPLICATION_SECRET,
      'Content-Length': Buffer.byteLength(body),
    },
  };
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

exports.handler = async () => {
  let last;
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    last = await callReconcile();

    let failed = null;
    try {
      failed = JSON.parse(last.body).synced.failed;
    } catch (e) {
      // unparseable body - treat as a failure worth retrying
    }

    console.log(
      'reconcile attempt ' + attempt + '/' + MAX_ATTEMPTS + ':',
      last.status,
      last.body
    );

    if (last.status === 200 && failed === 0) {
      return { attempts: attempt, ...last };
    }
    if (attempt < MAX_ATTEMPTS) {
      await sleep(BACKOFF_MS);
    }
  }
  console.log('reconcile did not reach failed:0 after all attempts');
  return { attempts: MAX_ATTEMPTS, ...last };
};
