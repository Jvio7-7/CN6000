const { reconcileToPeer } = require('/opt/nodejs/db');

// Triggers a failback resync: pushes every local record to the peer cloud
// so anything it missed while it was down gets filled in. Safe to run any
// time (the peer upserts are idempotent). Returns how many rows were sent
// per table.
exports.handler = async () => {
  try {
    const result = await reconcileToPeer();
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'reconciled', synced: result }),
    };
  } catch (err) {
    console.error('Reconcile failed:', err);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Reconcile failed' }),
    };
  }
};
